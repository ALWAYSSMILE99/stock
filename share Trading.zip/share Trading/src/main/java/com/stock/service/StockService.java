package com.stock.service;

import java.util.List;

import com.stock.bean.Stock;
import com.stock.exception.StockException;

public interface StockService {

	public List<Stock> createStock(Stock pro) throws StockException;
	public Stock findSingleStock(Integer id) throws StockException;
	public void deleteStock (Integer id) throws StockException;
	public List<Stock> viewAllStock() throws StockException;
	public List<Stock> updateStock(Integer id, Stock bo) throws StockException;
	
	
}
